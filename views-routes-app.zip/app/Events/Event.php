<?php

namespace Acelle\Events;

abstract class Event
{
}
