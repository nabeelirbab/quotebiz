<?php

namespace Acelle\Library\Exception;

use Exception;

class QuotaExceeded extends Exception
{
    // nothing here
}
