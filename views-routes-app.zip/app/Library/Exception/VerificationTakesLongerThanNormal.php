<?php

namespace Acelle\Library\Exception;

use Exception;

class VerificationTakesLongerThanNormal extends Exception
{
    // nothing here
}
