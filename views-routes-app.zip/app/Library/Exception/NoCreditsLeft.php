<?php

namespace Acelle\Library\Exception;

use Exception;

class NoCreditsLeft extends Exception
{
    // nothing here
}
