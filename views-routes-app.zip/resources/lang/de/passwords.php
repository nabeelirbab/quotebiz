<?php return array (
  'password' => 'Passwörter müssen übereinstimmen und mindestens sechs Zeichen lang sein.',
  'reset' => 'Ihr Passwort wurde zurückgesetzt!',
  'sent' => 'Wir haben einen Passwort-Reset-Link per E-Mail gesendet!',
  'token' => 'Dieses Passwort-Reset-Token ist ungültig.',
  'user' => 'Wir können keinen Benutzer mit dieser E-Mail-Adresse finden.',
) ?>