<?php return array (
  'previous' => '« Vorherige',
  'next' => 'Nächste »',
) ?>