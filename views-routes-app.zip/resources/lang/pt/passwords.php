<?php return array (
  'password' => 'A senha tem de contyer melo menos seis caracteres e tem de corresponder à confirmação.',
  'reset' => 'A sua senha foi alterada!',
  'sent' => 'Verifique a sua caixa de Email e clique no link enviado para recuperar a sua senha!',
  'token' => 'Recuperação inválida.',
  'user' => 'Utilizador inexistente com este endereço de e-mail.',
) ?>