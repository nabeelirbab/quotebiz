<?php return array (
  'failed' => 'これらの資格は、私たちの記録と一致しません。.',
  'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
) ?>